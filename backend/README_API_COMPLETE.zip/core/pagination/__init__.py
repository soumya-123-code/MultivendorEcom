from .custom import StandardResultsPagination, LargeResultsPagination

__all__ = ['StandardResultsPagination', 'LargeResultsPagination']
