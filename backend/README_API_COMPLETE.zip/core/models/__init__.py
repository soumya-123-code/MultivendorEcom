from .base import BaseModel, TimeStampedModel

__all__ = ['BaseModel', 'TimeStampedModel']
