# Core utilities package
default_app_config = 'core.apps.CoreConfig'
